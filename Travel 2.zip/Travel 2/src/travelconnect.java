/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Li wei
 */
import java.sql.*; //import java sql library
import javax.swing.*; // import java swing property
public class travelconnect {
    Connection conn = null;
    //database connection class porperties
    public static Connection ConnectDb(){
        
        try{
            Class.forName("com.mysql.jdbc.Driver"); //database driver description , load JDBC DRIVER for DB
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3308/travel7","root",""); //database connection string
            // open the database connection
            //JOptionPane.showMessageDialog(null, "Connected with database");
            return conn;
        }catch(Exception e){
        // if database server not found then exception will be arise
        JOptionPane.showMessageDialog(null, e);
        return null;
        
        
        }
        
        
        
    }
    
    
    
    
}
